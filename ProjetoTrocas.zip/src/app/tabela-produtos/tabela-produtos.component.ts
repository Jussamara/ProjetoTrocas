import { Component, OnInit } from '@angular/core';
import { CrudProdutosService} from "app/crud-produtos.service";
import { Produto} from "app/produto";

@Component({
  selector: 'app-tabela-produtos',
  templateUrl: './tabela-produtos.component.html',
  styleUrls: ['./tabela-produtos.component.css']
})
export class TabelaProdutosComponent implements OnInit {
  titulo = "Tabela de Trocas";
  produtos:Produto[]=[];
  constructor(private servico:CrudProdutosService ) { }

  ngOnInit() {
    this.produtos=this.servico.getProdutos();
  }
  remover(produto:Produto){
    this.servico.removerProduto(produto);
  }

}
