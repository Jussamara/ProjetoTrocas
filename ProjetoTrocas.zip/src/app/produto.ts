export class Produto {
    id: number;
    nome: string;
    descricao: string;
    local: string;
    img: any;
}