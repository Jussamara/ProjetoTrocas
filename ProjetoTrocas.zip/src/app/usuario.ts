export class Usuario {
    codigo: number;
    nome: string;
    email: string;
    senha: string;
}