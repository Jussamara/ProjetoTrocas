export class Produto {
    id: number;
    nome: string;
    descricao: string;
    estado: string;
    cidade: string;
    img: any;
    constructor(){}
}