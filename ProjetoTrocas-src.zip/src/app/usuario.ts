export class Usuario {
    id: number;
    nome: string;
    email: string;
    telefone: string;
    senha: string;
}